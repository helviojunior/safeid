using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.DirectoryServices;
using System.Collections;
using System.Collections.Specialized;
using System.Globalization;
using System.Management;
using System.Text.RegularExpressions;
using IAM.PluginInterface;
using System.DirectoryServices.AccountManagement;
using System.Reflection;

namespace Windows
{


    public class WindowsPlugin : PluginConnectorBase
    {

        public override String GetPluginName() { return "IAM for Microsoft Windows Plugin"; }
        public override String GetPluginDescription() { return "Plugin para integragir com base de dados de usuários do Microsoft Windows"; }

        public override Uri GetPluginId()
        {
            return new Uri("connector://iam/plugins/windows");
        }

        public override PluginConfigFields[] GetConfigFields()
        {

            List<PluginConfigFields> conf = new List<PluginConfigFields>();
            conf.Add(new PluginConfigFields("Host", "server", "IP ou nome do windows para conexão", PluginConfigTypes.String, true, ""));
            conf.Add(new PluginConfigFields("Usuário", "username", "Usuário para conexão", PluginConfigTypes.String, true, ","));
            conf.Add(new PluginConfigFields("Senha", "password", "Senha para conexão", PluginConfigTypes.Password, true, ","));

            return conf.ToArray();
        }


        public override PluginConnectorConfigActions[] GetConfigActions()
        {

            List<PluginConnectorConfigActions> conf = new List<PluginConnectorConfigActions>();
            conf.Add(new PluginConnectorConfigActions("Adição/remoção em grupo", "group", "Adicionar/remover o usuário em um grupo", "Nome do grupo", "group_name", "Nome do grupo que o usuário será adicionado/removido"));

            return conf.ToArray();
        }

        //

        public override PluginConnectorBaseFetchResult FetchFields(Dictionary<String, Object> config)
        {
            PluginConnectorBaseFetchResult ret = new PluginConnectorBaseFetchResult();

            LogEvent iLog = new LogEvent(delegate(Object sender, PluginLogType type, string text)
            {
                if (Log != null)
                    Log(sender, type, text);
            });


            if (!CheckInputConfig(config, true, iLog, true, true))
            {
                ret.success = false;
                return ret;
            }

            List<PluginConfigFields> cfg = new List<PluginConfigFields>();
            PluginConfigFields[] tmpF = this.GetConfigFields();
            foreach (PluginConfigFields cf in tmpF)
            {
                try
                {
                    iLog(this, PluginLogType.Information, "Field " + cf.Name + " (" + cf.Key + "): " + (config.ContainsKey(cf.Key) ? config[cf.Key].ToString() : "empty"));
                }
                catch (Exception ex)
                {
                    iLog(this, PluginLogType.Information, "Field " + cf.Name + " (" + cf.Key + "): error on get data -> " + ex.Message);
                }
            }
            
            try
            {

                LocalWindows lWin = new LocalWindows(config["server"].ToString(), config["username"].ToString(), config["password"].ToString());

                try
                {
                    lWin.Bind();
                }
                catch (Exception ex)
                {
                    iLog(this, PluginLogType.Error, "Error on connect to Windows '" + config["server"].ToString() + "': " + ex.Message + (ex.InnerException != null ? " " + ex.InnerException.Message : ""));
                    lWin = null;
                    ret.success = false;
                    return ret;
                }

                Log(this, PluginLogType.Information, "Successfully connected on " + config["server"].ToString());

                Log(this, PluginLogType.Information, "Trying to list the users...");

                Int32 count = 0;
                try
                {
                    PropertyInfo[] propertyInfos = typeof(UserPrincipal).GetProperties(BindingFlags.Public |
                                        BindingFlags.Static);

                    foreach (PropertyInfo p in propertyInfos)
                        if (!ret.fields.ContainsKey(p.Name))
                            ret.fields.Add(p.Name, new List<string>());

                    foreach (UserPrincipal user in lWin.ListAllUsers())
                    {
                        if (count >= 20)
                            break;

                        try
                        {
                            foreach (PropertyInfo p in propertyInfos)
                            {
                                Object value = p.GetValue(user, null);


                                //Separa os itens que mecessita algum tratamento
                                switch (p.Name.ToLower())
                                {

                                    default:
                                        ret.fields[p.Name].Add(value.ToString());
                                        break;
                                }
                            }

                            count++;

                        }
                        catch (Exception ex)
                        {
                            Log(this, PluginLogType.Error, "Erro ao importar o registro (" + user.SamAccountName + "): " + ex.Message);
                        }

                    }
                }
                catch (Exception ex)
                {
                    Log(this, PluginLogType.Error, "Erro listar os usuários");
                    throw ex;
                }

                ret.success = true;
            }
            catch (Exception ex)
            {
                iLog(this, PluginLogType.Error, ex.Message);
            }

            return ret;
        }

        public override Boolean TestPlugin(Dictionary<String, Object> config, List<PluginConnectorBaseDeployPackageMapping> fieldMapping)
        {
            return true;
        }

        public override Boolean ValidateConfigFields(Dictionary<String, Object> config, Boolean checkDirectoryExists, LogEvent Log, Boolean checkImport, Boolean checkDeploy)
        {

            LogEvent iLog = new LogEvent(delegate(Object sender, PluginLogType type, string text)
            {
                if (Log != null)
                    Log(sender, type, text);
            });

            if (!CheckInputConfig(config, checkDirectoryExists, iLog, checkImport, checkDeploy))
                return false;

            //Verifica as informações próprias deste plugin
            return true;
        }

        public override void ProcessImport(String cacheId, String importId, Dictionary<String, Object> config, List<PluginConnectorBaseDeployPackageMapping> fieldMapping)
        {
            if (!CheckInputConfig(config, true, Log))
                return;

            List<String> prop = new List<String>();

            try
            {

                LocalWindows lWin = new LocalWindows(config["server"].ToString(), config["username"].ToString(), config["password"].ToString());

                try
                {
                    lWin.Bind();
                }
                catch (Exception ex)
                {
                    Log2(this, PluginLogType.Error, 0, 0, "Error on connect to Windows '" + config["server"].ToString() + "': " + ex.Message + (ex.InnerException != null ? ex.InnerException.Message : ""), "");
                    lWin = null;
                    return;
                }

                Log(this, PluginLogType.Information, "Successfully connected on " + config["server"].ToString());

                Log(this, PluginLogType.Information, "Trying to list the users...");
                PropertyInfo[] propertyInfos = typeof(UserPrincipal).GetProperties(BindingFlags.Public |
                                        BindingFlags.Static);

                foreach (UserPrincipal user in lWin.ListAllUsers())
                {
                    PluginConnectorBaseImportPackageUser package = new PluginConnectorBaseImportPackageUser(importId);
                    try
                    {
                        PrincipalSearchResult<Principal> groups = user.GetGroups();

                        foreach (Principal ob in groups)
                        {
                            if (ob is GroupPrincipal)
                            {
                                // Create object for each group. 
                                GroupPrincipal obGpEntry = (GroupPrincipal)ob;
                                package.AddProperty("memberOf", obGpEntry.Name, (fieldMapping.Exists(f => (f.dataName == "memberOf")) ? fieldMapping.Find(f => (f.dataName == "memberOf")).dataType : "string"));
                            }
                        }

                        foreach (PropertyInfo p in propertyInfos)
                        {
                            //Separa os itens que mecessita algum tratamento
                            switch (p.Name.ToLower())
                            {
                                case "lastlogon":

                                    try
                                    {
                                        DateTime? dt = (DateTime?)user.LastLogon;

                                        if ((dt.HasValue) && (dt.Value.Year > 1970))//Se a data for inferior nem envia
                                            package.AddProperty(p.Name, dt.Value.ToString("yyyy-MM-dd HH:mm:ss"), (fieldMapping.Exists(f => (f.dataName == p.Name)) ? fieldMapping.Find(f => (f.dataName == p.Name)).dataType : "string"));

                                    }
                                    catch (Exception ex)
                                    { }
                                    break;

                                case "loginhours":
                                    break;

                                case "sid":
                                    try
                                    {
                                        package.AddProperty(p.Name, user.Sid.Value, (fieldMapping.Exists(f => (f.dataName == p.Name)) ? fieldMapping.Find(f => (f.dataName == p.Name)).dataType : "string"));
                                    }
                                    catch (Exception ex)
                                    { }
                                    break;

                                default:
                                    Object obj = p.GetValue(user, null);
                                    package.AddProperty(p.Name, obj.ToString(), (fieldMapping.Exists(f => (f.dataName == p.Name)) ? fieldMapping.Find(f => (f.dataName == p.Name)).dataType : "string"));
                                    break;
                            }
                        }

                        ImportPackageUser(package);
                    }
                    catch (Exception ex)
                    {
                        Log(this, PluginLogType.Error, "Erro ao importar o registro (" + user.SamAccountName + "): " + ex.Message);
                    }
                    finally
                    {
                        package.Dispose();
                        package = null;
                    }

                }

            }
            catch (Exception ex)
            {
                Log(this, PluginLogType.Error, ex.Message);
            }


        }


        public override void ProcessDeploy(String cacheId, PluginConnectorBaseDeployPackage package, Dictionary<String, Object> config, List<PluginConnectorBaseDeployPackageMapping> fieldMapping)
        {

            if (!CheckInputConfig(config, true, Log))
                return;

            try
            {

                LocalWindows lWin = new LocalWindows(config["server"].ToString(), config["username"].ToString(), config["password"].ToString());

                try
                {
                    lWin.Bind();
                }
                catch (Exception ex)
                {
                    Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on connect to Windows '" + config["server"].ToString() + "': " + ex.Message + (ex.InnerException != null ? ex.InnerException.Message : ""), "");
                    lWin = null;
                    return;
                }


                String login = package.login;
                String container = package.container;

                if (login == "")
                {
                    Log2(this, PluginLogType.Error, package.entityId, package.identityId, "IAM Login not found in properties list", "");
                    return;
                }

                if (container == "")
                    container = "IAMUsers";

                UserPrincipal user = lWin.FindUser(package.login);

                try
                {
                    if (user == null)
                    {
                        //Usuário não encontrado, cria
                        if (package.password == "")
                        {
                            package.password = IAM.Password.RandomPassword.Generate(16);
                            Log2(this, PluginLogType.Warning, package.entityId, package.identityId, "User not found in AD and IAM Password not found in properties list, creating a random password (" + package.password + ")", "");
                        }

                        lWin.AddUser(package.login, package.password);
                        user = lWin.FindUser(package.login);

                        Log2(this, PluginLogType.Information, package.entityId, package.identityId, "User added", "");
                    }
                }
                catch (Exception ex)
                {
                    Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on add user: " + ex.Message, "");
                    return;
                }

                
                //Limpa as flags que serão verificadas por este sistema
                if ((user.IsAccountLockedOut()) && (!package.temp_locked))
                    user.UnlockAccount();
                else if ((!user.IsAccountLockedOut()) && (package.temp_locked))
                    try
                    {
                        DirectoryEntry entry = (DirectoryEntry)user.GetUnderlyingObject();

                        UserFlags ctrl = (UserFlags)entry.InvokeGet("userFlags");

                        ctrl = (UserFlags)((Int32)ctrl + UserFlags.ACCOUNTDISABLE);
                        
                        if ((ctrl & UserFlags.ACCOUNTDISABLE) == UserFlags.ACCOUNTDISABLE)
                            ctrl -= UserFlags.ACCOUNTDISABLE;

                        if ((package.locked) || (package.temp_locked))
                            ctrl = (UserFlags)((Int32)ctrl + UserFlags.ACCOUNTDISABLE);

                        try
                        {
                            entry.Invoke("Put", new object[] { "UserFlags", (Int32)ctrl });
                            entry.CommitChanges();
                        }
                        catch (Exception ex)
                        {
                            Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on set user flags: " + ex.Message, "");
                            return;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on get user flags: " + ex.Message, "");
                        return;
                    }
                
                try
                {
                    //Executa as ações do RBAC
                    if ((package.pluginAction != null) && (package.pluginAction.Count > 0))
                    {
                        foreach (PluginConnectorBaseDeployPackageAction act in package.pluginAction)
                            try
                            {
                                switch (act.actionKey.ToLower())
                                {
                                    case "group":
                                        if (act.actionType == PluginActionType.Add)
                                        {
                                            String grpCN = lWin.FindOrCreateGroup(act.actionValue);
                                            if (lWin.AddUserToGroup(user.Name, grpCN))
                                                Log2(this, PluginLogType.Information, package.entityId, package.identityId, "User added in group " + act.actionValue + " by role " + act.roleName, "");
                                        }
                                        else if (act.actionType == PluginActionType.Remove)
                                        {
                                            String grpCN = lWin.FindOrCreateGroup(act.actionValue);
                                            if (lWin.RemoveUserFromGroup(user.Name, grpCN))
                                                Log2(this, PluginLogType.Information, package.entityId, package.identityId, "User removed from group " + act.actionValue + " by role " + act.roleName, "");
                                        }
                                        break;

                                    default:
                                        Log2(this, PluginLogType.Warning, package.entityId, package.identityId, "Action not recognized: " + act.actionKey, "");
                                        break;
                                }
                            }
                            catch (Exception ex)
                            {
                                Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on execute action (" + act.actionKey + "): " + ex.Message, "");
                            }
                    }


                    try
                    {

                        if (!String.IsNullOrWhiteSpace(package.password))
                            user.SetPassword(package.password);

                        user.Save();
                    }
                    catch (Exception ex)
                    {
                        Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on set user password: " + ex.Message, "");
                        return;
                    }

                    NotityChangeUser(this, package.entityId);

                    if (package.password != "")
                        Log2(this, PluginLogType.Information, package.entityId, package.identityId, "User updated with password", "");
                    else
                        Log2(this, PluginLogType.Information, package.entityId, package.identityId, "User updated without password", "");

                }
                finally
                {
                    //user.Close();
                }

            }
            catch (Exception ex)
            {
                Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on process deploy: " + ex.Message, "");
            }
        }


        public override void ProcessDelete(String cacheId, PluginConnectorBaseDeployPackage package, Dictionary<String, Object> config, List<PluginConnectorBaseDeployPackageMapping> fieldMapping)
        {

            if (!CheckInputConfig(config, true, Log))
                return;

            try
            {

                LocalWindows lWin = new LocalWindows(config["server"].ToString(), config["username"].ToString(), config["password"].ToString());

                try
                {
                    lWin.Bind();
                }
                catch (Exception ex)
                {
                    Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on connect to Windows '" + config["server"].ToString() + "': " + ex.Message, "");
                    lWin = null;
                    return;
                }


                String login = package.login;
                String container = package.container;

                if (login == "")
                {
                    Log2(this, PluginLogType.Error, package.entityId, package.identityId, "IAM Login not found in properties list", "");
                    return;
                }

                if (container == "")
                    container = "IAMUsers";

                UserPrincipal user = lWin.FindUser(package.login);

                if (user == null)
                {
                    Log2(this, PluginLogType.Warning, package.entityId, package.identityId, "User not found", "");
                    return;
                }

                user.Delete();

                NotityDeletedUser(this, package.entityId, package.identityId);

                if (package.password != "")
                    Log2(this, PluginLogType.Information, package.entityId, package.identityId, "User updated with password", "");
                else
                    Log2(this, PluginLogType.Information, package.entityId, package.identityId, "User updated without password", "");


            }
            catch (Exception ex)
            {
                Log2(this, PluginLogType.Error, package.entityId, package.identityId, "Error on process deploy: " + ex.Message, "");
            }
        }


        public override event LogEvent Log;
        public override event ImportPackageUserEvent ImportPackageUser;
        public override event ImportPackageStructEvent ImportPackageStruct;
        public override event LogEvent2 Log2;
        public override event NotityChangeUserEvent NotityChangeUser;
        public override event NotityChangeUserEvent NotityDeletedUser;
    }
}
