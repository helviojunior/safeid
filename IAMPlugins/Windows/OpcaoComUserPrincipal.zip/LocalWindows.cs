using System;
using System.Collections.Generic;
using System.Text;
using System.DirectoryServices;
using System.Security.Principal;
using System.Security.AccessControl;
using System.Globalization;
using System.Collections.Specialized;
using System.Management;
using System.Text.RegularExpressions;
using System.DirectoryServices.AccountManagement;

namespace Windows
{

    enum UserFlags
    {
        SCRIPT = 1,        // 0x1
        ACCOUNTDISABLE = 2,        // 0x2
        HOMEDIR_REQUIRED = 8,        // 0x8
        LOCKOUT = 16,       // 0x10
        PASSWD_NOTREQD = 32,       // 0x20
        PASSWD_CANT_CHANGE = 64,       // 0x40
        ENCRYPTED_TEXT_PASSWORD_ALLOWED = 128,      // 0x80
        TEMP_DUPLICATE_ACCOUNT = 256,      // 0x100
        NORMAL_ACCOUNT = 512,      // 0x200
        INTERDOMAIN_TRUST_ACCOUNT = 2048,     // 0x800
        WORKSTATION_TRUST_ACCOUNT = 4096,     // 0x1000
        SERVER_TRUST_ACCOUNT = 8192,     // 0x2000
        DONT_EXPIRE_PASSWD = 65536,    // 0x10000
        MNS_LOGON_ACCOUNT = 131072,   // 0x20000
        SMARTCARD_REQUIRED = 262144,   // 0x40000
        TRUSTED_FOR_DELEGATION = 524288,   // 0x80000
        NOT_DELEGATED = 1048576,  // 0x100000
        USE_DES_KEY_ONLY = 2097152,  // 0x200000
        DONT_REQUIRE_PREAUTH = 4194304,  // 0x400000
        PASSWORD_EXPIRED = 8388608,  // 0x800000
        TRUSTED_TO_AUTHENTICATE_FOR_DELEGATION = 16777216 // 0x1000000
    };

    class LocalWindows
    {
        private String _serverIP;
        private String _ldapBase;
        private String _username;
        private String _passwd;
        //private String _objectClassConta;
        //private String _userAttribute;
        //private String _passwdAtribute;
        private String _groupAtribute;
        //private Boolean _openned;
        //DirectoryEntry _deRoot;
        PrincipalContext _context;

        public String GroupAttribute { get { return _groupAtribute; } set { _groupAtribute = value; } }
        public PrincipalContext Context { get { return _context; } }

        public LocalWindows(String ServerIP)
        {
            _serverIP = ServerIP;
        }

        public LocalWindows(String ServerIP, String Username, String Password)
        {
            _serverIP = ServerIP;
            _username = Username;
            _passwd = Password;
        }

        public void Bind()
        {
            _context = new PrincipalContext(ContextType.Machine, _serverIP, null, _username, _passwd);

            //if (!_context.ValidateCredentials(_username, _passwd))
            //    throw new Exception("Invalid username/password");

            //Teste de conexão
            UserPrincipal user = new UserPrincipal(_context);
            user.Name = "*";

            PrincipalSearcher _searcher = new PrincipalSearcher();
            _searcher.QueryFilter = user;

            _searcher.FindOne();

            /*
            //_ldapBase = "WinNT://" + _serverIP;
            String step = "";
            try
            {
                _ldapBase = string.Format("WinNT://{0}/{1},user", _serverIP, _username);
                try
                {
                    step = "Auth secure";
                    _deRoot = new DirectoryEntry(_ldapBase, _username, _passwd, AuthenticationTypes.Secure);

                    object nativeObject = _deRoot.NativeObject;
                    step = "Set parent on auth secure";
                    _deRoot = _deRoot.Parent;
                    nativeObject = _deRoot.NativeObject;

                }
                catch(Exception ex)
                {
                    if ((ex is System.Runtime.InteropServices.COMException) && (((System.Runtime.InteropServices.COMException)ex).ErrorCode == -2147024891))
                    {
                        throw new Exception("Access denied on create DOM object (-2147024891/0x80070005)", ex);
                    }
                    else
                    {
                        step = "Auth";
                        _deRoot = new DirectoryEntry(_ldapBase, _username, _passwd);

                        object nativeObject = _deRoot.NativeObject;
                        step = "Set parent";
                        _deRoot = _deRoot.Parent;
                        nativeObject = _deRoot.NativeObject;
                    }
                }
            }
            catch (Exception ex3)
            {
#if DEBUG
                step += " " + _passwd;
#endif

                if ((ex3 is System.Runtime.InteropServices.COMException) && (((System.Runtime.InteropServices.COMException)ex3).ErrorCode == -2147024891))
                {
                    throw new Exception("Access denied on create DOM object (-2147024891/0x80070005)", ex3);
                }
                else
                {

                    String code = "";
                    if (ex3 is System.Runtime.InteropServices.COMException)
                    {
                        Byte[] tmp = BitConverter.GetBytes(((System.Runtime.InteropServices.COMException)ex3).ErrorCode);
                        Array.Reverse(tmp);
                        code = "0x" + BitConverter.ToString(tmp).Replace("-", "");
                    }


                    throw new Exception("Erro " + (code != "" ? "(" + code + ")" : "") + " on bind with path '" + _ldapBase + "' (" + step + ")", ex3);
                }
            }*/
        }

        
        public UserPrincipal FindUser(String login)
        {
            return UserPrincipal.FindByIdentity(_context, login);
        }

        public GroupPrincipal FindGroup(String group)
        {
            return GroupPrincipal.FindByIdentity(_context, group);
        }

        public Boolean AddUser(String login, String password)
        {

            if(UserPrincipal.FindByIdentity(_context, login) != null)
                throw new Exception("Login already exists");

            
            //A primeira senha é gerada randomicamente para cumprir com todos os sequisitos de complexidade
            //Para evitar erro ao inserir o usuário
            String tPwd = IAM.Password.RandomPassword.Generate(16);

            UserPrincipal _user = new UserPrincipal(_context, login, tPwd, true);
            _user.UserCannotChangePassword = true;
            _user.PasswordNeverExpires = true;
            _user.Save();
            
            //Define a senha correta do usuário
            _user.SetPassword(password);
            _user.Save();

            return true;
        }

        public String FindOrCreateGroup(String groupName)
        {
            GroupPrincipal g = FindGroup(groupName);
            if (g == null)
            {
                g = new GroupPrincipal(_context, groupName);
                g.Save();
                return g.SamAccountName;
            }
            else
            {
                return g.SamAccountName;
            }
        }

        public Boolean AddUserToGroup(String UserName, String GroupName)
        {
            try
            {
                GroupPrincipal _group = FindGroup(GroupName);
                UserPrincipal _user = FindUser(UserName);

                if (_group == null)
                    throw new Exception("Group '" + GroupName + "' not found");

                if (_user == null)
                    throw new Exception("User '" + UserName + "' not found");

                _group.Members.Add(_user);
                _group.Save();

                return true;
            }
            catch { return false; }
        }

        public Boolean RemoveUserFromGroup(String UserName, String GroupName)
        {
            try
            {
                GroupPrincipal _group = FindGroup(GroupName);
                UserPrincipal _user = FindUser(UserName);

                if (_group == null)
                    throw new Exception("Group '" + GroupName + "' not found");

                if (_user == null)
                    throw new Exception("User '" + UserName + "' not found");

                _group.Members.Remove(_user);
                _group.Save();

                return true;
            }
            catch { return false; }
        }

        public List<UserPrincipal> ListAllUsers()
        {
            List<UserPrincipal> ret = new List<UserPrincipal>();
            
            UserPrincipal user = new UserPrincipal(_context);
            user.Name = "*";
            
            PrincipalSearcher _searcher = new PrincipalSearcher();
            _searcher.QueryFilter = user;

            foreach (Principal childEntry in _searcher.FindAll())
                if (childEntry is UserPrincipal)
                {
                    /*DirectoryEntry user = _Find(_deRoot, "User", childEntry.Name); //entry.Children.Find(usr, "User");

                    if (user == null)
                        continue;*/

                    ret.Add((UserPrincipal)childEntry);
                }


            return ret;
        }
        
    }
}
